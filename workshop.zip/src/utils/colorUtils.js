const light = {
  background: 'white',
};

const dark = {
  background: 'black',
};

const themeColors = {
  light,
  dark,
};

export default themeColors;
