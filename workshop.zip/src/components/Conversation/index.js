import React from "react";
import { Divider, Flex, Stack, Avatar } from "@chakra-ui/core";
import CommitDescription from "../CommitDescription";

export default function Conversation({
  avatarUrl,
  enabledCommitDescription = false,
  extraLine = false,
  children,
}) {
  return (
    <Stack>
      <Flex>
        <Avatar name="Dan Abrahmov" src={avatarUrl} />
        <Stack flex="1" ml="6">
          {enabledCommitDescription && <CommitDescription />}
          {extraLine && (
            <Divider
              orientation="vertical"
              borderColor="red.500"
              height="5"
              ml="5"
            />
          )}
          {children}
          {extraLine && (
            <Divider
              orientation="vertical"
              borderColor="red.500"
              height="5"
              ml="5"
            />
          )}
        </Stack>
      </Flex>
    </Stack>
  );
}
